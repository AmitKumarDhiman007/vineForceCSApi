﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using WebApplication1.Models;

namespace WebApplication1.Reposetery
{
    
        public interface IVineCurd
        {
             List<VineCurdModel> GetCountriesList();
           // public Task<IEnumerable<VineCurdModel>> GetProductById(int Id);
           // public Task<int> AddProductAsync(VineCurdModel VineCurd);
          //  public Task<int> UpdateProductAsync(VineCurdModel VineCurd);
           // public Task<int> DeleteProductAsync(int Id);
        }
    }
