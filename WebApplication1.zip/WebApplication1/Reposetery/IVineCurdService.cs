﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using WebApplication1.Models;

namespace WebApplication1.Reposetery
{
    //public class IVineCurdService
    //{
        public interface IVineCurdService
    {
            //public Task<List<VineCurdModel>> GetProductList();
            //public Task<IEnumerable<VineCurdModel>> GetProductById(int Id);
            //public Task<int> AddProductAsync(VineCurdModel VineCurd);
            //public Task<int> UpdateProductAsync(VineCurdModel VineCurd);
            //public Task<int> DeleteProductAsync(int Id);
        }
    }
