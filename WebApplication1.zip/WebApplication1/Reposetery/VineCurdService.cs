﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using System.Web;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Reposetery
{
    public class VineCurdService
    {
       /// <summary>
       /// delete country using country name
       /// </summary>
       /// <param name="CountryName"></param>
       /// <returns></returns>
        public string deleteCountry(string CountryName)
        {
            DbContextClass objConn = new DbContextClass();
            SqlConnection Conn = objConn.GetConnection;
            Conn.Open();

            try
            {
                List<VineCurdModel> _listCustomer = new List<VineCurdModel>();

                if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                SqlCommand objCommand = new SqlCommand("CountryDelete", Conn);
                objCommand.CommandType = CommandType.StoredProcedure;
                
                objCommand.Parameters.AddWithValue("@CountryName", CountryName);
               
                SqlDataReader _Reader = objCommand.ExecuteReader();
                return "Record Delete";
            }
            catch
            {
                throw;
            }
            finally
            {
                if (Conn != null)
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                        Conn.Dispose();
                    }
                }
            }
        }

        public string DeleteState(string StateName)
        {
            DbContextClass objConn = new DbContextClass();
            SqlConnection Conn = objConn.GetConnection;
            Conn.Open();

            try
            {
                List<VineCurdModel> _listCustomer = new List<VineCurdModel>();

                if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                SqlCommand objCommand = new SqlCommand("StateDelete", Conn);
                objCommand.CommandType = CommandType.StoredProcedure;

                objCommand.Parameters.AddWithValue("@StateName", StateName);

                SqlDataReader _Reader = objCommand.ExecuteReader();
                return "Record state Delete";
            }
            catch
            {
                throw;
            }
            finally
            {
                if (Conn != null)
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                        Conn.Dispose();
                    }
                }
            }
        }

        /// <summary>
        /// show the country list
        /// </summary>
        /// <returns></returns>
        public List<VineCurdModel> GetCountriesList()
        {
                DbContextClass objConn = new DbContextClass();
                SqlConnection Conn = objConn.GetConnection;
                Conn.Open();

                try
                {
                    List<VineCurdModel> _listCustomer = new List<VineCurdModel>();

                    if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                    SqlCommand objCommand = new SqlCommand("Countries_CRUD", Conn);
                    objCommand.CommandType = CommandType.StoredProcedure;
                    var ActionValue = "SELECT";
                    objCommand.Parameters.AddWithValue("@Action", ActionValue.ToLower());
                    objCommand.Parameters.AddWithValue("@Name", null);
                    objCommand.Parameters.AddWithValue("@ISO", null);
                    SqlDataReader _Reader = objCommand.ExecuteReader();
                    while (_Reader.Read())
                    {
                    VineCurdModel objCust = new VineCurdModel();
                        objCust.Name = _Reader["Name"].ToString();
                    objCust.ISO = _Reader["ISO"].ToString();                      
                        _listCustomer.Add(objCust);
                    }

                    return _listCustomer;
                }
                catch
                {
                    throw;
                }
                finally
                {
                    if (Conn != null)
                    {
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                            Conn.Dispose();
                        }
                    }
                }
            }

        /// <summary>
        /// Add new country
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        public string AddNewCountry(VineCurdModel model)
        {
            DbContextClass objConn = new DbContextClass();
            SqlConnection Conn = objConn.GetConnection;
            Conn.Open();

            try
            {
                List<VineCurdModel> _listCustomer = new List<VineCurdModel>();

                if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                SqlCommand objCommand = new SqlCommand("Countries_CRUD", Conn);
                objCommand.CommandType = CommandType.StoredProcedure;
                var ActionValue = "insert";
                objCommand.Parameters.AddWithValue("@Action", ActionValue.ToLower());
                objCommand.Parameters.AddWithValue("@Name", model.Name);
                objCommand.Parameters.AddWithValue("@ISO", model.ISO);
                SqlDataReader _Reader = objCommand.ExecuteReader();             
                return "Data save";
            }
            catch
            {
                throw;
            }
            finally
            {
                if (Conn != null)
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                        Conn.Dispose();
                    }
                }
            }
        }
        /// <summary>
        /// filter by country iso
        /// </summary>
        /// <param name="ISO"></param>
        /// <returns></returns>
        public List<VinestateCurdModel> GetStatesListByFilter(string ISO)
        {
            DbContextClass objConn = new DbContextClass();
            SqlConnection Conn = objConn.GetConnection;
            Conn.Open();

            try
            {
                List<VinestateCurdModel> _listCustomer = new List<VinestateCurdModel>();

                if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                SqlCommand objCommand = new SqlCommand("GetStatesByCountryId", Conn);
                objCommand.CommandType = CommandType.StoredProcedure;
                var ActionValue = ISO;               
                objCommand.Parameters.AddWithValue("@ISO", ActionValue.ToLower());
                SqlDataReader _Reader = objCommand.ExecuteReader();
                while (_Reader.Read())
                {
                    VinestateCurdModel objCust = new VinestateCurdModel();
                    objCust.STATENAME = _Reader["STATENAME"].ToString();
                    objCust.ISO = _Reader["ISO"].ToString();
                    _listCustomer.Add(objCust);
                }

                return _listCustomer;
            }


            catch
            {
                throw;
            }
            finally
            {
                if (Conn != null)
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                        Conn.Dispose();
                    }
                }
            }
        }
         
        /// <summary>
        /// Add new state
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
             public string AddNewSTATE(VinestatecreateCurdModel model)
        {
            DbContextClass objConn = new DbContextClass();
            SqlConnection Conn = objConn.GetConnection;
            Conn.Open();

            try
            {
                List<VinestatecreateCurdModel> _liststate = new List<VinestatecreateCurdModel>();

                if (Conn.State != System.Data.ConnectionState.Open) Conn.Open();

                SqlCommand objCommand = new SqlCommand("CREATEStatesByCountryISO", Conn);
                objCommand.CommandType = CommandType.StoredProcedure;
                var ActionValue = model.ISO;
                objCommand.Parameters.AddWithValue("@STATENAME", model.STATENAME);
                objCommand.Parameters.AddWithValue("@ISO", ActionValue.ToLower());
                objCommand.Parameters.AddWithValue("@COUNTRYISO", model.COUNTRYID);
                SqlDataReader _Reader = objCommand.ExecuteReader();
                return "STATE save";
            }
            catch
            {
                throw;
            }
            finally
            {
                if (Conn != null)
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                        Conn.Dispose();
                    }
                }
            }
        }


    }

   
}