﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using WebApplication1.Models;
using WebApplication1.Reposetery;

namespace WebApplication1.Controllers
{
    // [RoutePrefix("api/VineCurd")]
    [EnableCors(origins: "*", headers: "*", methods: "*", exposedHeaders: "X-My-Header")]
    public class VineCurdController : ApiController
    {
      //  TextVineinfoDBEntities entities = new TextVineinfoDBEntities();
        // GET: api/VineCurd?GetCountriesList  
        [HttpGet]
        [Route("api/VineCurd/GetCountriesList")]
        public List<VineCurdModel> GetCountriesList()
        {
            try
            {

                VineCurdService objCrd = new VineCurdService();
                List<VineCurdModel> modelCust = objCrd.GetCountriesList();
                return modelCust;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("api/VineCurd/AddNewCountry")]
        public string AddNewCountry(VineCurdModel model)
        {
            try
            {
                VineCurdService objCrd = new VineCurdService();
                string obj = objCrd.AddNewCountry(model);
                return obj;
            }
            catch(Exception ex)
            {
                throw ex;
            }

            
        }

        [HttpGet]
        [Route("api/VineCurd/GetStatesListByFilter")]
        public List<VinestateCurdModel> GetStatesListByFilter(string ISO)
        {
            try
            {
                VineCurdService objCrd = new VineCurdService();
                List<VinestateCurdModel> modelCust = objCrd.GetStatesListByFilter(ISO);
                return modelCust;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
       // createSTATE(data:any)

             [HttpPost]
        [Route("api/VineCurd/AddNewSTATE")]
        public string AddNewSTATE(VinestatecreateCurdModel model)
        {
            try
            {
                VineCurdService objCrd = new VineCurdService();
                string obj = objCrd.AddNewSTATE(model);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        [HttpDelete]
        [Route("api/VineCurd/deleteCountry")]
        public string deleteCountry(string CountryName)
        {
            try
            {
                VineCurdService objCrd = new VineCurdService();
                string obj = objCrd.deleteCountry(CountryName);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        [HttpDelete]
        [Route("api/VineCurd/DeleteState")]
        public string DeleteState(string StateName)
        {
            try
            {
                VineCurdService objCrd = new VineCurdService();
                string obj = objCrd.DeleteState(StateName);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


    }
}
