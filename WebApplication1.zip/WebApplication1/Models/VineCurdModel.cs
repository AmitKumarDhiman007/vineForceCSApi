﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class VineCurdModel
    {

       // public int? Id { get; set; }
        public string Name { get; set; }
        public string ISO { get; set; }
     
    }

    public class VinestateCurdModel
    {

        // public int? Id { get; set; }    STATENAME, ISO
        public string STATENAME { get; set; }
        public string ISO { get; set; }

    }

    public class VinestatecreateCurdModel
    {
        public string STATENAME { get; set; }
        public string ISO { get; set; }
        public string COUNTRYID { get; set; }

    }
}