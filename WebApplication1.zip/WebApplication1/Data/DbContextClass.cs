﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.Data
{
    public class DbContextClass 
    {
        private SqlConnection SqlConn = null;

        public SqlConnection GetConnection
        {
            get { return SqlConn; }
            set { SqlConn = value; }
        }

        public DbContextClass()
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            SqlConn = new SqlConnection(ConnectionString);
        }

    }
}